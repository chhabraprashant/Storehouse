package com.duckservice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.duckservice.model.OrderRO;
import com.duckservice.utils.QueueComprator;

@Service
public class OrderService {

	private static PriorityQueue<OrderRO> pQueue = OrderQueue.getInstance().getQueue();

	public OrderRO addOrder(OrderRO orderRO) {
		if (isValid(orderRO.getClientID())) {// check if client id is in range
			OrderQueue.getInstance().getQueue().add(orderRO);
			orderRO.setMsg("Order Created..");
			return orderRO;
		}
		OrderRO order = new OrderRO();
		order.setMsg("Order cannot be created!!");
		return order;
	}

	public OrderRO nextDelivery() {
		OrderRO order = pQueue.poll();
		if (!ObjectUtils.isEmpty(order))
			order.setMsg("Order Delivered...");
		return order;
	}

	public OrderRO deleteOrder(int clientId) {
		OrderRO order;
		if (!ObjectUtils.isEmpty(clientId)) {
			order = getStatus(clientId, pQueue);
			if (pQueue.remove(order)) {
				order.setMsg("Order Deleted successfully..");
				return order;
			}
		}

		order = new OrderRO();
		order.setMsg("Error while deleting order");

		return order;
	}

	public List<OrderRO> getAllOrdersAndWaitTime() {
		List<OrderRO> response = new ArrayList<OrderRO>();
		List<OrderRO> unsortedList = new ArrayList<OrderRO>();
		unsortedList.addAll(pQueue);
		unsortedList.sort(new QueueComprator());
		for (OrderRO o : unsortedList) {
			response.add(getStatus(o.getClientID(), unsortedList));
		}
		return response;
	}

	public OrderRO getStatus(int clientID, Collection<OrderRO> lst) {
		OrderRO orderRO = null;
		int position = 1,waitTime = 0,qty = 0,noOfWaits = 1;
		if (ObjectUtils.isEmpty(lst)) {
			List<OrderRO> unsortedList = new ArrayList<OrderRO>();
			unsortedList.addAll(pQueue);
			unsortedList.sort(new QueueComprator());
			lst = unsortedList;
		}
		for (OrderRO o : lst) {
			if (o.getClientID() == clientID) {
				orderRO = o;
				qty = qty + o.getProductqty();
				break;
			}
			position = position + 1;
			qty = qty + o.getProductqty();
		}
		if (null != orderRO) {
			noOfWaits = Math.abs(qty / 25);
			noOfWaits = (qty%25 != 0)? noOfWaits + 1: noOfWaits;
			// waitTime = (position - 1)*5 ;
				// waitTime = (waitTime + qty / 25) * 5;
				waitTime = noOfWaits * 5;
			orderRO.setPosition(position);
			orderRO.setWaitTime(waitTime);
			orderRO.setMsg(null);
		} else {
			orderRO = new OrderRO();
			orderRO.setMsg("No record found");
		}

		return orderRO;
	}

	public boolean isValid(int clientId) {
		Optional<OrderRO> order = pQueue.stream().filter(t -> t.getClientID() == clientId).findFirst();
		if (!ObjectUtils.isEmpty(clientId) && ObjectUtils.isEmpty(order)) {
			String regex = "^([0-9][0-9]{0,3}|1[0-9]{0,4}|20000)$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(String.valueOf(clientId));
			if (matcher.find()) {
				return true;
			}
		}
		return false;
	}
}
