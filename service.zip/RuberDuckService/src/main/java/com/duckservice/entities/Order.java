package com.duckservice.entities;

public class Order
{
    private final int _quantity;

    public Order( int quantity )
    {
        _quantity = quantity;
    }

    public int getQuantity()
    {
        return _quantity;
    }

    @Override
    public String toString()
    {
        return "Order{" +
                "_quantity=" + _quantity +
                '}';
    }
}
