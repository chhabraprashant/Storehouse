package com.duckservice.entities;

public class Customer
{
    private static final int PREMIUM_CUSTOMER_BORDER = 1000;

    private final boolean _premium;

    private final int _id;

    public Customer( int id )
    {
        _id = id;
        _premium = id < PREMIUM_CUSTOMER_BORDER;
    }

    public int getId()
    {
        return _id;
    }

    public boolean isPremium()
    {
        return _premium;
    }

    @Override
    public String toString()
    {
        return "Customer{premium=" + _premium + ", id=" + _id + '}';
    }
}
