package com.duckservice;

import java.util.PriorityQueue;

import com.duckservice.model.OrderRO;
import com.duckservice.utils.QueueComprator;

public class OrderQueue {
	private static OrderQueue orderQueue = null;
	private PriorityQueue<OrderRO> queue = null;
	
	private OrderQueue() {
		queue = new PriorityQueue<>(new QueueComprator());
	}

	public static OrderQueue getInstance() {
		if (null == orderQueue) {
			synchronized (OrderQueue.class) {
				if (null == orderQueue) {
					orderQueue = new OrderQueue();
				}
			}
		}

		return orderQueue;
	}
	
	public void addOrder(OrderRO orderRO) {
		this.queue.add(orderRO);
	}

	public PriorityQueue<OrderRO> getQueue() {
		return queue;
	}
}
