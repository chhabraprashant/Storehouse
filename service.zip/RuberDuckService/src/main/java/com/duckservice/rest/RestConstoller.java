package com.duckservice.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.duckservice.OrderService;
import com.duckservice.model.OrderRO;

@RestController
@RequestMapping( "/duckService" )
public class RestConstoller
{
	@Autowired
	private OrderService service;
    @RequestMapping( value = "/echo/{name}", method = RequestMethod.GET )
    public String echo( @PathVariable( "name" ) String name )
    {
        return "You said' " + name + "'";
    }
    @PostMapping(value = "/create")
    public OrderRO addOrder(@RequestBody OrderRO order)
    {
    	return service.addOrder(order);
    }
    @GetMapping(value = "/status/{clientId}")
	public OrderRO getQueuePositionAndWaitTime(@PathVariable ( "clientId" ) int clientId) {
		return service.getStatus(clientId,null);
	}

	@GetMapping(value = "/allOrders")
	public List<OrderRO> getAllOrdersAndWaitTime() {
		return service.getAllOrdersAndWaitTime();
	}

	@GetMapping(value = "/nextDelivery")
	public OrderRO nextDelivery() {
		return service.nextDelivery();
	}

	@DeleteMapping(value = "/deleteOrder/{clientId}")
	public OrderRO deleteOrder(@PathVariable ( "clientId" ) int clientId) {
		return service.deleteOrder(clientId);
	}
}
