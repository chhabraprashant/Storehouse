package com.duckservice.model;

public class OrderRO extends ResponseRO {
	private int clientID;
	private int productqty;
	private int waitTime;
	private int position;

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + clientID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderRO other = (OrderRO) obj;
		if (clientID != other.clientID)
			return false;
		return true;
	}

	public OrderRO(int clientID, int productqty) {
		super();
		this.clientID = clientID;
		this.productqty = productqty;
	}

	public OrderRO() {
		super();
	}

	public int getClientID() {
		return clientID;
	}

	public int getProductqty() {
		return productqty;
	}

	public void setClientID(int clientID) {
		this.clientID = clientID;
	}

	public void setProductqty(int productqty) {
		this.productqty = productqty;
	}

	public int getWaitTime() {
		return waitTime;
	}

	public void setWaitTime(int waitTime) {
		this.waitTime = waitTime;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	@Override
	public String toString() {
		return "OrderRO [clientID=" + clientID + ", productqty=" + productqty + ", waitTime=" + waitTime + ", position="
				+ position + "]";
	}

}
