package com.duckservice.utils;

import java.util.Comparator;

import com.duckservice.model.OrderRO;

public class QueueComprator implements Comparator<OrderRO> {

	@Override
	public int compare(OrderRO o1, OrderRO o2) {
		return o1.getClientID() > o2.getClientID() ? 1 : -1;
	}

}
